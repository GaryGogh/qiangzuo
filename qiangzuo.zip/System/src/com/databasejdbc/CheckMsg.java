/*
 * 显示某一房间住客信息
 */
package com.databasejdbc;
public class CheckMsg extends CheckOut{
	public CheckMsg(String str1, String path) {
		super(str1, path,null);
		this.cancel_bt.setVisible(false);
		this.checkout_bt.setVisible(false);
		this.tip_jl.setVisible(false);
		this.check_bt.setVisible(false);
		this.jl.setVisible(false);
		this.jtf.setVisible(false);
		// TODO Auto-generated constructor stub
	}
}
