/**====================================================**
 *     项目名             ：酒店管理系统
 *     模块名             ：数据库连接
 *     文件名             ：DataBaseConnct.java
 *     相关文件         ：
 *     实现功能         ：jdbc连接数据库
 *     函数说明         ：
 *     [## public Vector getId(){}]：
 *        功能：获取数据库中系统登录ID
 *
 *     [## public void setId() {}]:
 *        功能：设置数据库中系统登录ID
 *
 *     [## public Vector getPassword(){}]:
 *        功能：获取数据库中系统登录密码
 *
 *     [## public void setPassword(){}]:
 *        功能：设置数据库中系统登录密码
 *
 *     [## public Vector getRoonnum(){}]：
 *        功能：获取数据库中房间号
 *
 *     [## public void setRoonnum() {}]:
 *        功能：设置数据库中房间号
 *
 *     [## public Vector getRoomtype(){}]:
 *        功能：获取数据库中房间类型
 *
 *     [## public void seRoomtype(){}]:
 *        功能：设置数据库中房间类型
 *
 *     [## public void Sql(String sql){}]:
 *        功能：执行sql语句进行查询
 *
 **===================================================**/
package com.common;
import java.sql.*;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.xml.crypto.dsig.keyinfo.RetrievalMethod;
public class DataBaseConnect {
	private String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private String dbURL="jdbc:sqlserver://GARY:1433;DatabaseName=hotel_mangerment_system";
	private  String userName="sa";
	private String userPwd="123789";
	private  Connection ct=null;
	private ResultSet rs=null;
	private Statement st;
	private Vector id =new Vector();
	private Vector  password =new Vector();

	/**====================================================**
	 *          获取数据库中系统登录ID
	 **===================================================**/
	public Vector getId() {
		return id;
	}
	/**====================================================**
	 *          设置数据库中系统登录ID
	 **===================================================**/
	public void setId(Vector id) {
		this.id = id;
	}
	/**====================================================**
	 *          获取数据库中系统登录密码
	 **===================================================**/
	public Vector getPassword() {
		return password;
	}
	/**====================================================**
	 *          设置数据库中系统登录ID
	 **===================================================**/
	public void setPassword(Vector password) {
		this.password = password;
	}

	/**====================================================**
	 *     [## public void Sql(String sql) {}]   
	 *       参数      ：String sql
	 *       返回值  ：无
	 *       修饰符  ：public
	 *       功能  ：创建sql查询，从数据库里查询登陆账号与密码
	 **===================================================**/
	public void Sql(String sql) throws Exception
	{
		Class.forName(driverName);
		ct=DriverManager.getConnection(dbURL,userName,userPwd);
		st=ct.createStatement();
		rs=st.executeQuery(sql);
		while(rs.next())
		{
			id.add(rs.getInt(1));
			password.add(rs.getInt(2));
		}
		if(rs!=null)
			rs.close();
		if(st!=null)
			st.close();
		if(ct!=null)
			ct.close();
	}
	/**====================================================**
	 *     [## public Vector RoomOperation(int room_num) {}]  查询房间信息 
	 *       参数      ：int room_num
	 *       返回值  ：无
	 *       修饰符  ：public
	 *       功能  ：创建sql查询房间号与类型，类外可使用
	 **===================================================**/
	public Vector RoomOperation(int room_num)throws Exception
	{
		Vector<Object> data=new Vector<Object>();
		Class.forName(driverName);
		ct=DriverManager.getConnection(dbURL,userName,userPwd);
		st=ct.createStatement();
		rs=st.executeQuery("select * from room_table where roomnum="+room_num);
		while(rs.next())
		{
			data.add(rs.getInt(1));
			data.add(rs.getString(2));
			data.add(rs.getInt(3));
			data.add(rs.getInt(4));
		}
		if(rs!=null)
			rs.close();
		if(st!=null)
			st.close();
		if(ct!=null)
			ct.close();
		return data;
	}
	/**====================================================**
	 *     [## public void RoomOperation(String sql) {}]  查询房间使用状态
	 *       参数      ：String sql
	 *       返回值  ：房间个数
	 *       修饰符  ：public
	 *       功能  ：创建sql查询满足条件房间使用状态，类外可使用
	 **===================================================**/
	public int getRow(String sql)throws Exception
	{
		Class.forName(driverName);
		ct=DriverManager.getConnection(dbURL,userName,userPwd);
		int rowcount=0;
		st=ct.createStatement();
		rs=st.executeQuery(sql);
		while(rs.next())
		{
			rowcount++;
		}
		if(rs!=null)
			rs.close();
		if(st!=null)
			st.close();
		if(ct!=null)
			ct.close();
		return rowcount;
	}

	/**====================================================**
	 *     [## public  void insertData(){}] 插入记录
	 *       参数      ：String table_name,String str
	 *       返回值  ：无
	 *       修饰符  ：public
	 *       功能  ：向数据库中插入记录
	 **===================================================
	 * @throws Exception **/
	public void insertData(String table_name,String str) throws Exception
	{
		Class.forName(driverName);
		ct=DriverManager.getConnection(dbURL,userName,userPwd);
		ct.setAutoCommit(false);
		st=ct.createStatement();
		String sql="insert into"+" "+table_name+" "+"values"+"("+str+")";
		st.executeUpdate(sql);
		ct.commit();
		if(st!=null)
			st.close();
		if(ct!=null)
			ct.close();

	}
	/**====================================================**
	 *     [## public void updateData(String str){}] 更新记录
	 *       参数      ：String sql
	 *       返回值  ：无
	 *       修饰符  ：public
	 *       功能  ：向数据库中更新记录
	 **===================================================*/
	public void updateData(String sql) throws Exception
	{
		Class.forName(driverName);
		ct=DriverManager.getConnection(dbURL,userName,userPwd);
		ct.setAutoCommit(false);
		st=ct.createStatement();
		st.executeUpdate(sql);
		ct.commit();
		if(st!=null)
			st.close();
		if(ct!=null)
			ct.close();
	}
	/**====================================================**
	 *     [## public void getDataFromCostomer(){}] 从Costomer_table中获取数据
	 *       参数      ：int room_num
	 *       返回值  ：Vector<object> data
	 *       修饰符  ：public
	 *       功能  ：根据房间号从Costomer_table中获取数据并返回
	 **===================================================*/
	public Vector getDataFromCostomer(int room_num) throws Exception
	{
		Vector<Object> data=new Vector<Object>();
		Class.forName(driverName);
		ct=DriverManager.getConnection(dbURL,userName,userPwd);
		ct.setAutoCommit(false);
		st=ct.createStatement();
		rs=st.executeQuery("select * from costomer_table where roomnum="+room_num+"and isliving=1");
		while(rs.next())
		{
			data.add(rs.getInt(1));
			data.add(rs.getString(2));
			data.add(rs.getString(3));
			data.add(rs.getString(4));
			data.add(rs.getString(5));
			data.add(rs.getString(6));
			data.add(rs.getInt(7));
			data.add(rs.getInt(8));
			data.add(rs.getInt(9));
		}
		if(rs!=null)
			rs.close();
		if(st!=null)
			st.close();
		if(ct!=null)
			ct.close();
		return data;
	}

	/**====================================================**
	 *     [## public Vector RoomOperation(int room_num) {}]  查询房间信息 
	 *       参数      ：无
	 *       返回值  ：return returedata;
	 *       修饰符  ：public
	 *       功能  ：创建sql查询房间号与类型,与入住状态并返回，类外可使用
	 **===================================================**/
	public Vector RoomOperation()throws Exception
	{
		Vector<Vector> returedata=new Vector<Vector>();
		Vector<Object> roomnum=new Vector<Object>();
		Vector<Object> roomtype=new Vector<Object>();
		Vector<Integer> roomstate=new Vector<Integer>();
		Class.forName(driverName);
		ct=DriverManager.getConnection(dbURL,userName,userPwd);
		st=ct.createStatement();
		rs=st.executeQuery("select roomnum,roomtype,roomatate from room_table");
		while(rs.next())
		{
			roomnum.add(rs.getInt(1));
			roomtype.add(rs.getString(2));
			roomstate.add(rs.getInt(3));
		}
		if(rs!=null)
			rs.close();
		if(st!=null)
			st.close();
		if(ct!=null)
			ct.close();
		returedata.add(roomnum);
		returedata.add(roomtype);
		returedata.add(roomstate);
		return returedata;
	}
}


